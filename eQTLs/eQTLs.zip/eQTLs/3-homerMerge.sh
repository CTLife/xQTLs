out="3-noDup/homer"
mkdir  -p  $out


file=1_BA9_eQTLs.bed
mergePeaks  -strand  -d given   2-BED/$file   -prefix  $out       > $out/$file  


file=2_BA24_eQTLs.bed
mergePeaks  -strand  -d given   2-BED/$file   -prefix  $out       > $out/$file  


file=3_C_eQTLs.bed
mergePeaks  -strand  -d given   2-BED/$file   -prefix  $out       > $out/$file  


file=4_H_eQTLs.bed
mergePeaks  -strand  -d given   2-BED/$file   -prefix  $out       > $out/$file  


file=5_T_eQTLs.bed
mergePeaks  -strand  -d given   2-BED/$file   -prefix  $out       > $out/$file  




