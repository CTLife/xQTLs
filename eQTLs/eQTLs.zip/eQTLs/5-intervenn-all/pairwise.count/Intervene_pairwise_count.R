#!/usr/bin/env Rscript
if (suppressMessages(!require("corrplot"))) suppressMessages(install.packages("corrplot", repos="http://cran.us.r-project.org"))
library("corrplot")
svg("5-intervenn-all/pairwise.count/Intervene_pairwise_count.svg", width=10, height=10)

intersection_matrix <- as.matrix(read.table("5-intervenn-all/pairwise.count/Intervene_pairwise_count_matrix.txt"))
corrplot(intersection_matrix, method ="color", title="Pairwise intersection-Number of overlaps", tl.col="black", tl.cex=0.8, is.corr = FALSE, diag=FALSE, addrect=1, mar=c(0,0,2,1), rect.col = "black")
invisible(dev.off())
