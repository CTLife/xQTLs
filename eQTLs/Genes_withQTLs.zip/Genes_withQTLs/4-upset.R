library( "ComplexHeatmap" )


DF_1_BA9 <- read.table("2-BED/1_BA9_eGenes.txt", header=F,   sep="\t" )  
DF_2_BA24 <- read.table("2-BED/2_BA24_eGenes.txt", header=F,   sep="\t" )  
DF_3_C<- read.table("2-BED/3_C_eGenes.txt", header=F,   sep="\t" )  
DF_4_H <- read.table("2-BED/4_H_eGenes.txt", header=F,   sep="\t" )  
DF_5_T <- read.table("2-BED/5_T_eGenes.txt", header=F,   sep="\t" )  


dim( DF_1_BA9  ) 
dim( DF_2_BA24   )
dim( DF_3_C  )
dim( DF_4_H )
dim( DF_5_T  )

lt = list(genes_BA9 = DF_1_BA9[,1],
          genes_BA24 = DF_2_BA24[,1],
          genes_C = DF_3_C[,1],
          genes_H = DF_4_H[,1],
          genes_T = DF_5_T[,1]
          )


m1 = make_comb_mat(lt)
##  UpSet(m1) 

pdf( "overlap-upset.pdf" , width=10, height=3 )
UpSet(m1, pt_size = unit(5, "mm"), lwd = 1,
      comb_col = c("green4", "cyan", "red", "blue", "black")[comb_degree(m1)] ,
      top_annotation = upset_top_annotation(m1, add_numbers = TRUE),
      right_annotation = upset_right_annotation(m1, add_numbers = TRUE)  )

dev.off()
