#    venn                Venn diagram of intersection of genomic regions or genomic sets (upto 6-way).
#    upset               UpSet diagram of intersection of genomic regions or genomic sets.
#    pairwise            Pairwise intersection and heatmap of N genomic region sets in <BED/GTF/GFF> format.




A0=4-formatBED/1_BA9_eQTLs.bed
A1=4-formatBED/2_BA24_eQTLs.bed
A2=4-formatBED/3_C_eQTLs.bed
A3=4-formatBED/4_H_eQTLs.bed
A4=4-formatBED/5_T_eQTLs.bed




outdir="5-intervenn-all"
mkdir  $outdir 






## venn
##############################################################################
outpath1=$outdir/venn
mkdir  $outpath1
intervene  venn  --input  \
$A0  \
$A1  \
$A2  \
$A3  \
$A4  \
--type genomic    --save-overlaps   --output $outpath1  \
--dpi 1200  --figtype pdf   --figsize 12 12  --fontsize 10
##############################################################################




## upset
##############################################################################
outpath2=$outdir/upset
mkdir  $outpath2
intervene  upset  --input  \
$A0  \
$A1  \
$A2  \
$A3  \
$A4  \
--type   genomic    --save-overlaps   --output $outpath2  --ninter 100       \
--dpi 1200  --figtype pdf   --figsize 12 6   
##############################################################################






## pairwise
##############################################################################
outpath1="$outdir/pairwise.fraction"
mkdir -p $outpath1

intervene  pairwise  \
--input  \
$A0  \
$A1  \
$A2  \
$A3  \
$A4  \
--type   genomic  --sort  --compute  frac  --htype color   --output $outpath1  \
--dpi 1200  --figtype svg   --figsize 10 10  --fontsize 10



outpath2="$outdir/pairwise.count"
mkdir -p $outpath2

intervene  pairwise  \
--input  \
$A0  \
$A1  \
$A2  \
$A3  \
$A4  \
--type   genomic  --sort  --compute  count  --htype color  --output $outpath2  \
--dpi 1200  --figtype svg   --figsize 10 10   --fontsize 10




outpath2="$outdir/pairwise.jaccard"
mkdir -p $outpath2

intervene  pairwise  \
--input  \
$A0  \
$A1  \
$A2  \
$A3  \
$A4  \
--type   genomic  --sort  --compute  jaccard  --htype color  --output $outpath2  \
--dpi 1200  --figtype svg   --figsize 10 10   --fontsize 10
##############################################################################





























