#!/usr/bin/env Rscript
if (suppressMessages(!require("corrplot"))) suppressMessages(install.packages("corrplot", repos="http://cran.us.r-project.org"))
library("corrplot")
svg("3-intervenn-all/pairwise.fraction/Intervene_pairwise_frac.svg", width=10, height=10)

intersection_matrix <- as.matrix(read.table("3-intervenn-all/pairwise.fraction/Intervene_pairwise_frac_matrix.txt"))
corrplot(intersection_matrix, method ="color", title="Pairwise intersection-Fraction of overlap", tl.col="black", tl.cex=0.8, is.corr = FALSE, diag=FALSE, addrect=1, mar=c(0,0,2,1), rect.col = "black")
invisible(dev.off())
