

 Rscript 6_Anno_v20210106.R    \
        --inputDir=4-formatBED      \
        --outDir=6-Annotation     \
        --refGenome=hg38  \
        --stranded=TRUE    \
        --fast=TRUE        \
        --upstream=1000      \
        --downstream=0  
 

