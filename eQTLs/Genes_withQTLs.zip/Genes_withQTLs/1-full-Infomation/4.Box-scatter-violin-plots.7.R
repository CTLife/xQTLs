library("ggplot2") 

MyTheme_1_g <- function(textSize1=14, hjust1=1, vjust1=1,  angle1=30) {    # "hjust=1, vjust=1, angle=30" for some boxplots.
  theme(  
    line  = element_line(colour="black",  size=1.0,   linetype=1,      lineend=NULL),                                                                                        ## all line elements.          局部优先总体,下面3个也是,只对非局部设置有效.   所有线属性.
    rect  = element_rect(colour="black",  size=1.0,   linetype=1,      fill="transparent" ),                                                                                 ## all rectangluar elements.    hjust=1: 靠右对齐.   所有矩形区域属性.
    text  = element_text(family="serif",  face="plain",  colour="black",  size=textSize1, hjust=0.5, vjust=0.5,   angle=0, lineheight=1.0,  margin = NULL, debug = NULL),    ## all text elements.           "serif" for a serif font. 所有文本相关属性.
    title = element_text(family="serif",  face="plain",  colour="black",  size=textSize1, hjust=0.5, vjust=0.5,   angle=0, lineheight=1.0,  margin = NULL, debug = NULL),    ## all title elements: plot, axes, legends.    hjust:水平对齐的方向.  所有标题属性.
    ## aspect.ratio = 1,   ##高宽比
    
    axis.title    = element_text(family="serif", face="plain", colour="black", size=textSize1,    hjust=0.5,    vjust=0.5,    angle=0,       lineheight=1.0,  margin = NULL, debug = NULL),       ## label of axes (element_text; inherits from text).  horizontal: 水平的, 水平线 
    axis.title.x  = element_text(family="serif", face="plain", colour="black", size=textSize1,    hjust=0.5,    vjust=0.5,    angle=0,       lineheight=1.0,  margin = NULL, debug = NULL),       ## x axis label (element_text; inherits from axis.title)
    axis.title.y  = element_text(family="serif", face="plain", colour="black", size=textSize1,    hjust=0.5,    vjust=0.5,    angle=90,      lineheight=1.0,  margin = NULL, debug = NULL),       ## y axis label (element_text; inherits from axis.title)
    axis.text     = element_text(family="serif", face="plain", colour="black", size=textSize1,    hjust=0.5,    vjust=0.5,    angle=0,       lineheight=1.0,  margin = NULL, debug = NULL),       ## tick labels along axes (element_text; inherits from text). 坐标轴刻度的标签的属性.                                                         
    axis.text.x   = element_text(family="serif", face="plain", colour="black", size=textSize1,    hjust=hjust1, vjust=vjust1, angle=angle1,  lineheight=1.0,  margin = NULL, debug = NULL),       ## x axis tick labels (element_text; inherits from axis.text)
    axis.text.y   = element_text(family="serif", face="plain", colour="black", size=textSize1,    hjust=0.5,    vjust=0.5,    angle=0,       lineheight=1.0,  margin = NULL, debug = NULL),       ## y axis tick labels (element_text; inherits from axis.text)
    
    axis.ticks        = element_line(colour="black", size=0.5, linetype=1, lineend=NULL),          ## tick marks along axes (element_line; inherits from line). 坐标轴刻度线.
    axis.ticks.x      = element_line(colour="black", size=0.5, linetype=1, lineend=NULL),          ## x axis tick marks (element_line; inherits from axis.ticks)
    axis.ticks.y      = element_line(colour="black", size=0.5, linetype=1, lineend=NULL),          ## y axis tick marks (element_line; inherits from axis.ticks)
    axis.ticks.length = grid::unit(2.0,   "mm",   data=NULL),                                      ## length of tick marks (unit), ‘"mm"’ Millimetres.  10 mm = 1 cm.  刻度线长度
    axis.line         = element_line(colour="transparent", size=0.3, linetype=1, lineend=NULL), 	 ## lines along axes (element_line; inherits from line). 坐标轴线
    axis.line.x       = element_line(colour="transparent", size=0.3, linetype=1, lineend=NULL), 	 ## line along x axis (element_line; inherits from axis.line)
    axis.line.y       = element_line(colour="transparent", size=0.3, linetype=1, lineend=NULL),	   ## line along y axis (element_line; inherits from axis.line)
    
    legend.background    = element_rect(colour="transparent", size=1, linetype=1, fill="transparent" ), 	      ## background of legend (element_rect; inherits from rect)
    legend.spacing       = grid::unit(1, "mm", data=NULL), 	                                                    ## extra space added around legend (unit). linetype=1指的是矩形边框的类型.
    legend.key           = element_rect(colour="transparent", size=2, linetype=1, fill="transparent" ), 	      ## background underneath legend keys. 图例符号. size=1指的是矩形边框的大小.
    legend.key.size      = grid::unit(6,   "mm", data=NULL) , 	                                                ## size of legend keys   (unit; inherits from legend.key.size)
    legend.key.height    = grid::unit(6.5, "mm", data=NULL) , 	                                                ## key background height (unit; inherits from legend.key.size)
    legend.key.width     = grid::unit(8,   "mm", data=NULL) ,                                                   ## key background width  (unit; inherits from legend.key.size)
    legend.text          = element_text(family="serif", face=NULL, colour="black", size=textSize1, hjust=NULL, vjust=NULL, angle=NULL, lineheight=NULL), 	##legend item labels. 图例文字标签.
    legend.text.align    = 0, 	                    ## alignment of legend labels (number from 0 (left) to 1 (right))
    legend.title         = element_blank(),   	    ## title of legend (element_text; inherits from title)
    legend.title.align   = 0, 	                    ## alignment of legend title (number from 0 (left) to 1 (right))
    legend.position      = "right", 	              ## the position of legends. ("left", "right", "bottom", "top", or two-element numeric vector)
    legend.direction     = "vertical",        	    ## layout of items in legends  ("horizontal" or "vertical")   图例排列方向
    legend.justification = "center",      	        ## anchor point for positioning legend inside plot ("center" or two-element numeric vector)  图例居中方式
    legend.box           = NULL, 	                  ## arrangement of multiple legends ("horizontal" or "vertical")  多图例的排列方式
    legend.box.just      = NULL, 	                  ## justification of each legend within the overall bounding box, when there are multiple legends ("top", "bottom", "left", or "right")  多图例的居中方式
    
    panel.background   = element_rect(colour="transparent", size=0.0, linetype=1, fill="transparent" ),   	## background of plotting area, drawn underneath plot (element_rect; inherits from rect)
    panel.border       = element_rect(colour="black", size=0.5, linetype=1, fill=NA ), 	                    ## border around plotting area, drawn on top of plot so that it covers tick marks and grid lines. This should be used with fill=NA (element_rect; inherits from rect)
    panel.spacing      = grid::unit(1, "mm", data=NULL) , 	                                                ## margin around facet panels (unit)  分面绘图区之间的边距
    panel.spacing.x    = grid::unit(1, "mm", data=NULL) ,
    panel.spacing.y    = grid::unit(1, "mm", data=NULL) ,
    panel.grid         = element_blank(), 	                                                                ## grid lines (element_line; inherits from line)  绘图区网格线
    panel.grid.major   = element_line(colour="transparent", size=NULL, linetype=NULL, lineend=NULL) , 	    ## major grid lines (element_line; inherits from panel.grid)  主网格线
    panel.grid.minor   = element_line(colour="transparent", size=NULL, linetype=NULL, lineend=NULL) ,     	## minor grid lines (element_line; inherits from panel.grid)  次网格线
    panel.grid.major.x = element_line(colour="transparent", size=NULL, linetype=NULL, lineend=NULL) , 	    ## vertical major grid lines (element_line; inherits from panel.grid.major)
    panel.grid.major.y = element_line(colour="transparent", size=NULL, linetype=NULL, lineend=NULL) ,     	## horizontal major grid lines (element_line; inherits from panel.grid.major)
    panel.grid.minor.x = element_line(colour="transparent", size=NULL, linetype=NULL, lineend=NULL) ,     	## vertical minor grid lines (element_line; inherits from panel.grid.minor)
    panel.grid.minor.y = element_line(colour="transparent", size=NULL, linetype=NULL, lineend=NULL) ,     	## horizontal minor grid lines (element_line; inherits from panel.grid.minor)
    
    plot.background	= element_rect(colour="transparent", size=NULL, linetype=NULL, fill="transparent" ),                                                ## background of the entire plot (element_rect; inherits from rect)  整个图形的背景
    plot.title      = element_text(family="serif", face=NULL, colour="black", size=textSize1, hjust=0.5, vjust=0.5,   angle=NULL, lineheight=NULL),     ## plot title (text appearance) (element_text; inherits from title)  图形标题
    plot.margin     = grid::unit(c(5, 5, 5, 5), "mm", data=NULL), 	                                                                                    ## margin around entire plot (unit with the sizes of the top, right, bottom, and left margins)
    
    strip.background = element_rect(colour=NULL,    size=NULL, linetype=NULL, fill=NULL ), 	                                                      ## background of facet labels (element_rect; inherits from rect)  分面标签背景
    strip.text       = element_text(family="serif", face=NULL, colour=NULL, size=NULL, hjust=NULL, vjust=NULL, angle=NULL, lineheight=NULL), 	    ## facet labels (element_text; inherits from text)
    strip.text.x     = element_text(family="serif", face=NULL, colour=NULL, size=NULL, hjust=NULL, vjust=NULL, angle=NULL, lineheight=NULL), 	    ## facet labels along horizontal direction (element_text; inherits from strip.text)
    strip.text.y     = element_text(family="serif", face=NULL, colour=NULL, size=NULL, hjust=NULL, vjust=NULL, angle=NULL, lineheight=NULL)   	  ## facet labels along vertical direction (element_text; inherits from strip.text) 
  ) 
} 


MySaveGgplot2_1_g <- function(ggplot2Figure1,  path1, fileName1,  height1, width1) {
  SVG1 <- paste(path1,  "/",  "SVG",  sep = "",  collapse = NULL)
  PNG1 <- paste(path1,  "/",  "PNG",  sep = "",  collapse = NULL)
  PDF1 <- paste(path1,  "/",  "PDF",  sep = "",  collapse = NULL)
  EPS1 <- paste(path1,  "/",  "EPS",  sep = "",  collapse = NULL)
  if( ! file.exists(SVG1) ) { dir.create(SVG1) }
  if( ! file.exists(PNG1) ) { dir.create(PNG1) }
  if( ! file.exists(PDF1) ) { dir.create(PDF1) }
  if( ! file.exists(EPS1) ) { dir.create(EPS1) }
  ggsave( filename = paste(SVG1,  "/",  fileName1,  ".svg",  sep="",  collapse=NULL),     height=height1,    width=width1,      dpi = 1200 )
  ggsave( filename = paste(PNG1,  "/",  fileName1,  ".png",  sep="",  collapse=NULL),     height=height1,    width=width1,      dpi = 1200 )
  ggsave( filename = paste(PDF1,  "/",  fileName1,  ".pdf",  sep="",  collapse=NULL),     height=height1,    width=width1,      dpi = 1200 )
  ggsave( filename = paste(EPS1,  "/",  fileName1,  ".eps",  sep="",  collapse=NULL),     height=height1,    width=width1,      dpi = 1200,   device=cairo_ps)         
}


## Added scatter plot
MyBoxViolinPlot_2 <- function(vector2, xAxis2,  sampleType2,    path2,   fileName2,    title2,  xLab2,  yLab2,   height2=4,  width2=4,   Ymin2=0, Ymax2=3, alpha2=0.4) {                                                     
  vector2[vector2>Ymax2] <- Ymax2
  vector2[vector2<Ymin2] <- Ymin2
  DataFrame1  <- data.frame(   sampleType=sampleType2,  xAxis=xAxis2,  yAxis=vector2 )  
  
  FigureTemp1 <- ggplot( DataFrame1, aes( x=xAxis, fill=sampleType  ) ) +   
    geom_jitter(aes(y=yAxis), size=0.1, colour="grey1", alpha=alpha2, position = position_jitter(width=0.25) ) +
    geom_boxplot( alpha=0, width=0.7,   aes(y=yAxis),  outlier.size=0,  size=0.7,  fill=NA, colour="red") +    
    xlab(xLab2 ) + ylab( yLab2 ) + ggtitle( title2 )  + MyTheme_1_g(textSize1=14, hjust1=1, vjust1=1,  angle1=30 )  + ylim(Ymin2, Ymax2 )
  MySaveGgplot2_1_g(ggplot2Figure1=FigureTemp1,  path1=path2, fileName1=paste(fileName2, "-ScatterBoxPlot",        sep="",  collapse=NULL),  height1=height2, width1=width2)
  
  FigureTemp2 <- ggplot(DataFrame1, aes( x=xAxis, fill=sampleType  ) ) +   
    geom_jitter(aes(y=yAxis), size=0.1, colour="grey1", alpha=alpha2, position = position_jitter(width=0.25) ) +
    geom_violin(aes(y=yAxis), fill = NA, colour = "blue", adjust = 3,  alpha=0, size=0.6) +  
    geom_boxplot( alpha=0, width=0.3,   aes(y=yAxis),  outlier.size=0,  size=0.6,  fill=NA, colour="red" ) +    
    stat_summary(   aes(y=yAxis),   fun.y=mean, colour="yellow3", geom="point", shape=19, size=0.0, show.legend = FALSE) + 
    xlab(xLab2 ) + ylab( yLab2 ) + ggtitle( title2 )  + MyTheme_1_g(textSize1=14, hjust1=1, vjust1=1,  angle1=30 )  + ylim(Ymin2, Ymax2 )
  MySaveGgplot2_1_g(ggplot2Figure1=FigureTemp2,  path1=path2, fileName1=paste(fileName2, "-ViolinPlot-3adjust",    sep="",  collapse=NULL),  height1=height2, width1=width2)
  
  FigureTemp3 <- ggplot(DataFrame1, aes( x=xAxis, fill=sampleType  ) ) +  
    geom_jitter(aes(y=yAxis), size=0.1, colour="grey1", alpha=alpha2, position = position_jitter(width=0.25) ) +
    geom_violin(aes(y=yAxis), fill = NA, colour = "blue",   alpha=0, size=0.6) +  
    geom_boxplot( alpha=0, width=0.3,   aes(y=yAxis),  outlier.size=0,  size=0.6,  fill=NA, colour="red" ) +    
    stat_summary(   aes(y=yAxis),   fun.y=mean, colour="yellow3", geom="point", shape=19, size=0.0, show.legend = FALSE) + 
    xlab(xLab2 ) + ylab( yLab2 ) + ggtitle( title2 )  + MyTheme_1_g(textSize1=14, hjust1=1, vjust1=1,  angle1=30 )  + ylim(Ymin2, Ymax2 )
  MySaveGgplot2_1_g(ggplot2Figure1=FigureTemp3,  path1=path2, fileName1=paste(fileName2, "-ViolinPlot-noAdjust",   sep="",  collapse=NULL),  height1=height2, width1=width2)
}  




My_Box_Violin_Scatte_Plot <- function(vector2,   sampleType2,    path2,   fileName2,    title2,  xLab2,  yLab2,   height2=4,  width2=4,   Ymin2=0, Ymax2=3, alpha2=0.4) {                                                     
  vector2[vector2>Ymax2] <- Ymax2
  vector2[vector2<Ymin2] <- Ymin2
  myQ4 = quantile(vector2, probs = seq(0, 1, 0.25) )
  IQR = myQ4[4]-myQ4[2]
  myUP = myQ4[4]+1.5*IQR # Upper Range  
  myLow = myQ4[2]-1.5*IQR # Lower Range
  if(myUP < Ymax2 ) {Ymax2 = myUP}
  if(myLow > Ymin2 ) {Ymin2 = myLow}
  vector2[vector2>Ymax2] <- Ymax2
  vector2[vector2<Ymin2] <- Ymin2
  DataFrame1  <- data.frame(   sampleType=sampleType2,   yAxis=vector2 )  
  
  FigureTemp1 <- ggplot( DataFrame1, aes(x=sampleType) ) +   
    geom_jitter(aes(y=yAxis), size=0.1, colour="grey1", alpha=alpha2, position = position_jitter(width=0.25) ) +
    geom_boxplot( alpha=0, width=0.5,   aes(y=yAxis),  outlier.size=0,    fill=NA, colour="red", lwd=0.1, fatten = 1) +   
    stat_summary(   aes(y=yAxis),   fun=mean, colour="cyan3", geom="point", shape=19, size=0.5, show.legend = FALSE) + 
    xlab(xLab2 ) + ylab( yLab2 ) + ggtitle( title2 )  + MyTheme_1_g(textSize1=12, hjust1=1, vjust1=1,  angle1=0 )  + ylim(Ymin2-0.01, Ymax2+0.01 )
  MySaveGgplot2_1_g(ggplot2Figure1=FigureTemp1,  path1=path2, fileName1=paste(fileName2, "-Scatter-Box-Plot",        sep="",  collapse=NULL),  height1=height2, width1=width2)
  
}  



## T test and Wilcoxon test  (unpaired).
MyHypothesisTest_1_f <- function(vector1, vector2, file1) {
  myTempFunction <- function() {
    
    sink(file=file1)
    print("######################## Apply continuity correction in the normal approximation for the p-value. ###############################################")
    
    print("##################################################################################################################################for comparing boxplot")
    wilcoxTest_2 <- wilcox.test(x=vector1, y=vector2, alternative="two.sided",  mu=0,   paired=FALSE,  exact=FALSE, correct=TRUE,  conf.int=TRUE,  conf.level=0.95)
    print( wilcoxTest_2  )
    cat( "\n\nExact p-value:", wilcoxTest_2$p.value, "\n\n\n\n\n" ) 
    
    print("##################################################################################################################################")
    wilcoxTest_4 <- wilcox.test(x=vector1, y=vector2, alternative="less",       mu=0,   paired=FALSE,  exact=FALSE, correct=TRUE,  conf.int=TRUE,  conf.level=0.95)
    print( wilcoxTest_4  )
    cat( "\n\nExact p-value:", wilcoxTest_4$p.value, "\n\n\n\n\n" )
    print("##################################################################################################################################")
    
    print("##################################################################################################################################")
    wilcoxTest_6 <- wilcox.test(x=vector1, y=vector2, alternative="greater",    mu=0,   paired=FALSE,  exact=FALSE, correct=TRUE,  conf.int=TRUE,  conf.level=0.95)
    print( wilcoxTest_6  )
    cat( "\n\nExact p-value:", wilcoxTest_6$p.value, "\n\n\n\n\n\n" )
    
    
    print("######################## Don't apply continuity correction in the normal approximation for the p-value. ###############################################")
    print("##################################################################################################################################")
    
    print("##################################################################################################################################")
    wilcoxTestB_2 <- wilcox.test(x=vector1, y=vector2, alternative="two.sided",  mu=0,   paired=FALSE,  exact=FALSE, correct=FALSE,  conf.int=TRUE,  conf.level=0.95)
    print( wilcoxTestB_2  )
    cat( "\n\nExact p-value:", wilcoxTestB_2$p.value, "\n\n\n\n\n" ) 
    print("##################################################################################################################################")
    
    print("##################################################################################################################################")
    wilcoxTestB_4 <- wilcox.test(x=vector1, y=vector2, alternative="less",       mu=0,   paired=FALSE,  exact=FALSE, correct=FALSE,  conf.int=TRUE,  conf.level=0.95)
    print( wilcoxTestB_4  )
    cat( "\n\nExact p-value:", wilcoxTestB_4$p.value, "\n\n\n\n\n" )
    print("##################################################################################################################################")
    
    print("##################################################################################################################################")
    wilcoxTestB_6 <- wilcox.test(x=vector1, y=vector2, alternative="greater",    mu=0,   paired=FALSE,  exact=FALSE, correct=FALSE,  conf.int=TRUE,  conf.level=0.95)
    print( wilcoxTestB_6  )
    cat( "\n\nExact p-value:", wilcoxTestB_6$p.value, "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n" )
    
    
    
    print("######################## T-test, var.equal=FALSE. ###############################################")
    print("##################################################################################################################################")
    
    print("##################################################################################################################################")
    tTest_2 <- t.test(x=vector1, y=vector2, alternative="two.sided",  mu=0,   paired=FALSE,   var.equal=FALSE,  conf.level=0.95)
    print( tTest_2  )
    cat( "\n\nExact p-value:", tTest_2$p.value, "\n\n\n\n\n" )
    print("##################################################################################################################################")
    
    print("##################################################################################################################################")
    tTest_4 <- t.test(x=vector1, y=vector2, alternative="less",       mu=0,   paired=FALSE,   var.equal=FALSE,  conf.level=0.95)
    print( tTest_4  )
    cat( "\n\nExact p-value:", tTest_4$p.value, "\n\n\n\n\n" )
    print("##################################################################################################################################")
    
    print("##################################################################################################################################")
    tTest_6 <- t.test(x=vector1, y=vector2, alternative="greater",    mu=0,   paired=FALSE,   var.equal=FALSE,  conf.level=0.95)
    print( tTest_6  )
    cat( "\n\nExact p-value:", tTest_6$p.value, "\n\n\n\n\n\n" )
    
    
    print("######################## T-test, var.equal=TRUE. ##############################################################################################")
    
    print("##################################################################################################################################")
    tTestB_2 <- t.test(x=vector1, y=vector2, alternative="two.sided",  mu=0,   paired=FALSE,   var.equal=TRUE,  conf.level=0.95)
    print( tTestB_2  )
    cat( "\n\nExact p-value:", tTestB_2$p.value, "\n\n\n\n\n" )
    print("##################################################################################################################################")
    
    print("##################################################################################################################################")
    tTestB_4 <- t.test(x=vector1, y=vector2, alternative="less",       mu=0,   paired=FALSE,   var.equal=TRUE,  conf.level=0.95)
    print( tTestB_4 )
    cat( "\n\nExact p-value:", tTestB_4$p.value, "\n\n\n\n\n" )
    
    print("##################################################################################################################################")
    tTestB_6 <- t.test(x=vector1, y=vector2, alternative="greater",    mu=0,   paired=FALSE,   var.equal=TRUE,  conf.level=0.95)
    print( tTestB_6  )
    cat( "\n\nExact p-value:", tTestB_6$p.value, "\n\n\n\n\n" )
    
    sink()
    
  }
  tryCatch(
    myTempFunction(),
    error = function(err){"descriptiveStatistics_f_9999999999999"}
  ) 
  
}





###########################################################################################################################################################################
DF_1 <- read.table("4_H_eGenes.txt", header=F,   sep="\t" )  
dim(DF_1 )
 #  DF_1[1:10,] 

distance = DF_1[,7] 
## hist(distance, breaks = 2000)
## length( distance )
## length( distance[ abs(distance) < 500000  ] )


numSamples = 18



DF_phe = DF_1[,27:(27+numSamples-1)] 
DF_gno = DF_1[,(27+numSamples+5):(27+numSamples+4+numSamples)] 
#  DF_phe[1:10,] 
#  DF_gno[1:10,]

DF_phe = as.matrix(DF_phe)
DF_gno = as.matrix(DF_gno)
dim(DF_phe )
dim(DF_gno )

DF_gno_times = matrix( nrow = nrow(DF_gno), ncol = 10 )

for( i in c(1:nrow(DF_gno)) ) {
  temp =  as.numeric( table(DF_gno[i,]) )
  if( length(temp) == 2) {  temp = c(temp[1:2], NA) }
  if( length(temp) == 3) {  temp = temp }  
  if( length(temp) == 4) {  print(i);  print(  table(DF_gno[i,]) );   temp =  temp[2:4]  }
  if( length(temp) == 5) {  print(i);  print(  table(DF_gno[i,]) );   temp =  temp[3:5]  }
  if( length(temp) == 6) {  print(i);  print(  table(DF_gno[i,]) );   temp =  temp[4:6]  }
  
  DF_gno_times[i,1:3] = temp
  temp = temp[!is.na(temp)]
  DF_gno_times[i,4] = sum(temp) 
  DF_gno_times[i,5] = max(temp)
  DF_gno_times[i,6] = min(temp) #########
  DF_gno_times[i,7] = min(temp)/max(temp)
  DF_gno_times[i,8] = min(temp)/sum(temp)
  DF_gno_times[i,9] = sum(temp) - max(temp) ##################
  DF_gno_times[i,10]= sum(temp) - max(temp) - min(temp) 
}

 
myBool = ( (DF_gno_times[,9] >= 6)  &   (DF_gno_times[,6] >= 2) )
length(myBool )
length(myBool[myBool])
 
DF_1   =  DF_1[myBool,]
DF_phe =  DF_phe[myBool,]
DF_gno =  DF_gno[myBool,]
print( dim(DF_1) )
print( dim(DF_phe) )
print( dim(DF_gno) )
print( "#####################################################################" )

AllResults_g <- "4_H_eGenes"
if( ! file.exists(AllResults_g) ) { dir.create(path=AllResults_g, recursive = TRUE) }

write.table(x=DF_1, file = paste(AllResults_g, "Kept.all.txt", sep="/"), append = FALSE, quote = FALSE, sep = "\t",
            eol = "\n", na = "NA", dec = ".", row.names = FALSE,  col.names = FALSE )



write.table(x=DF_1[,c(2,3,4,1,7,5)], file = paste(AllResults_g, "Kept.phenotype.bed", sep="/"), append = FALSE, quote = FALSE, sep = "\t",
            eol = "\n", na = "NA", dec = ".", row.names = FALSE,  col.names = FALSE )





distance = distance/1000

pdf(  paste(AllResults_g, "Raw.distance.pdf", sep="/") )
hist(distance, breaks = 20  ,   main = "Number of bins: 20",    xlab = "distance (kb)" , col="red" , border="grey"  )
hist(distance, breaks = 200  ,  main = "Number of bins: 200",   xlab = "distance (kb)" , col="red" , border="grey"  )
hist(distance, breaks = 2000  , main = "Number of bins: 2000",  xlab = "distance (kb)" , col="red" , border="grey"  )
dev.off()






pdf(  paste(AllResults_g, "Kept.distance.pdf", sep="/") )
hist(distance[myBool], breaks = 20  ,   main = "Number of bins: 20",    xlab = "distance (kb)" , col="red" , border="grey"  )
hist(distance[myBool], breaks = 200  ,  main = "Number of bins: 200",   xlab = "distance (kb)" , col="red" , border="grey"  )
hist(distance[myBool], breaks = 2000  , main = "Number of bins: 2000",  xlab = "distance (kb)" , col="red" , border="grey"  )
dev.off()   









pvalues = DF_1[,20] 
pOrder = order(pvalues)
##  pvalues[pOrder] 

#########################################

i=pOrder[1]
## DF_1[i,] 
myname = paste(DF_1[i,1], "and", DF_1[i,8], sep="  ")
My_Box_Violin_Scatte_Plot(vector2=as.vector(DF_phe[i,]),   sampleType2=as.vector(DF_gno[i,]),    
                          path2=AllResults_g,   fileName2=paste( "Top-1", i, sep="_"),    
                          title2=myname,  xLab2="Genotype",  yLab2="Phenotype",   
                          height2=5,  width2=4.5,   Ymin2=min(DF_phe[i,]), Ymax2=max(DF_phe[i,]),     alpha2=1)

i=pOrder[2]
## DF_1[i,] 
myname = paste(DF_1[i,1], "and", DF_1[i,8], sep="  ")
My_Box_Violin_Scatte_Plot(vector2=as.vector(DF_phe[i,]),   sampleType2=as.vector(DF_gno[i,]),    
                          path2=AllResults_g,   fileName2=paste( "Top-2", i, sep="_"),     
                          title2=myname,  xLab2="Genotype",  yLab2="Phenotype",   
                          height2=5,  width2=4.5,   Ymin2=min(DF_phe[i,]), Ymax2=max(DF_phe[i,]),    alpha2=1)

i=pOrder[3]
## DF_1[i,] 
myname = paste(DF_1[i,1], "and", DF_1[i,8], sep="  ")
My_Box_Violin_Scatte_Plot(vector2=as.vector(DF_phe[i,]),   sampleType2=as.vector(DF_gno[i,]),    
                          path2=AllResults_g,   fileName2=paste( "Top-3", i, sep="_"),     
                          title2=myname,  xLab2="Genotype",  yLab2="Phenotype",   
                          height2=5,  width2=4.5,     Ymin2=min(DF_phe[i,]), Ymax2=max(DF_phe[i,]),    alpha2=1)

i=pOrder[4]
i
## DF_1[i,] 
myname = paste(DF_1[i,1], "and", DF_1[i,8], sep="  ")
My_Box_Violin_Scatte_Plot(vector2=as.vector(DF_phe[i,]),   sampleType2=as.vector(DF_gno[i,]),    
                          path2=AllResults_g,   fileName2=paste( "Top-4", i, sep="_"),     
                          title2=myname,  xLab2="Genotype",  yLab2="Phenotype",   
                          height2=5,  width2=4.5,     Ymin2=min(DF_phe[i,]), Ymax2=max(DF_phe[i,]),    alpha2=1)

i=pOrder[5]
i
## DF_1[i,] 
myname = paste(DF_1[i,1], "and", DF_1[i,8], sep="  ")
My_Box_Violin_Scatte_Plot(vector2=as.vector(DF_phe[i,]),   sampleType2=as.vector(DF_gno[i,]),    
                          path2=AllResults_g,   fileName2=paste( "Top-5", i, sep="_"),    
                          title2=myname,  xLab2="Genotype",  yLab2="Phenotype",   
                          height2=5,  width2=4.5,     Ymin2=min(DF_phe[i,]), Ymax2=max(DF_phe[i,]),    alpha2=1)

i=pOrder[6]
i
## DF_1[i,] 
myname = paste(DF_1[i,1], "and", DF_1[i,8], sep="  ")
My_Box_Violin_Scatte_Plot(vector2=as.vector(DF_phe[i,]),   sampleType2=as.vector(DF_gno[i,]),    
                          path2=AllResults_g,   fileName2=paste( "Top-6", i, sep="_"),   
                          title2=myname,  xLab2="Genotype",  yLab2="Phenotype",   
                          height2=5,  width2=4.5,     Ymin2=min(DF_phe[i,]), Ymax2=max(DF_phe[i,]),    alpha2=1)

i=pOrder[7]
i
## DF_1[i,] 
myname = paste(DF_1[i,1], "and", DF_1[i,8], sep="  ")
My_Box_Violin_Scatte_Plot(vector2=as.vector(DF_phe[i,]),   sampleType2=as.vector(DF_gno[i,]),    
                          path2=AllResults_g,   fileName2=paste( "Top-7", i, sep="_"),      
                          title2=myname,  xLab2="Genotype",  yLab2="Phenotype",   
                          height2=5,  width2=4.5,     Ymin2=min(DF_phe[i,]), Ymax2=max(DF_phe[i,]),    alpha2=1)

i=pOrder[8]
i
## DF_1[i,] 
myname = paste(DF_1[i,1], "and", DF_1[i,8], sep="  ")
My_Box_Violin_Scatte_Plot(vector2=as.vector(DF_phe[i,]),   sampleType2=as.vector(DF_gno[i,]),    
                          path2=AllResults_g,   fileName2=paste( "Top-8", i, sep="_"),  
                          title2=myname,  xLab2="Genotype",  yLab2="Phenotype",   
                          height2=5,  width2=4.5,     Ymin2=min(DF_phe[i,]), Ymax2=max(DF_phe[i,]),    alpha2=1)

i=pOrder[9]
i
## DF_1[i,] 
myname = paste(DF_1[i,1], "and", DF_1[i,8], sep="  ")
My_Box_Violin_Scatte_Plot(vector2=as.vector(DF_phe[i,]),   sampleType2=as.vector(DF_gno[i,]),    
                          path2=AllResults_g,   fileName2=paste( "Top-9", i, sep="_"),  
                          title2=myname,  xLab2="Genotype",  yLab2="Phenotype",   
                          height2=5,  width2=4.5,     Ymin2=min(DF_phe[i,]), Ymax2=max(DF_phe[i,]),     alpha2=1)

i=pOrder[10]
i
## DF_1[i,] 
myname = paste(DF_1[i,1], "and", DF_1[i,8], sep="  ")
My_Box_Violin_Scatte_Plot(vector2=as.vector(DF_phe[i,]),   sampleType2=as.vector(DF_gno[i,]),    
                          path2=AllResults_g,   fileName2=paste( "Top-10", i, sep="_"),   
                          title2=myname,  xLab2="Genotype",  yLab2="Phenotype",   
                          height2=5,  width2=4.5,      Ymin2=min(DF_phe[i,]), Ymax2=max(DF_phe[i,]),  alpha2=1)





i=pOrder[11]
## DF_1[i,] 
myname = paste(DF_1[i,1], "and", DF_1[i,8], sep="  ")
My_Box_Violin_Scatte_Plot(vector2=as.vector(DF_phe[i,]),   sampleType2=as.vector(DF_gno[i,]),    
                          path2=AllResults_g,  fileName2=paste( "Top-11", i, sep="_"),    
                          title2=myname,  xLab2="Genotype",  yLab2="Phenotype",   
                          height2=5,  width2=4.5,   Ymin2=min(DF_phe[i,]), Ymax2=max(DF_phe[i,]),     alpha2=1)

i=pOrder[12]
## DF_1[i,] 
myname = paste(DF_1[i,1], "and", DF_1[i,8], sep="  ")
My_Box_Violin_Scatte_Plot(vector2=as.vector(DF_phe[i,]),   sampleType2=as.vector(DF_gno[i,]),    
                          path2=AllResults_g,   fileName2=paste( "Top-12", i, sep="_"),   
                          title2=myname,  xLab2="Genotype",  yLab2="Phenotype",   
                          height2=5,  width2=4.5,   Ymin2=min(DF_phe[i,]), Ymax2=max(DF_phe[i,]),    alpha2=1)

i=pOrder[13]
## DF_1[i,] 
myname = paste(DF_1[i,1], "and", DF_1[i,8], sep="  ")
My_Box_Violin_Scatte_Plot(vector2=as.vector(DF_phe[i,]),   sampleType2=as.vector(DF_gno[i,]),    
                          path2=AllResults_g,   fileName2=paste( "Top-13", i, sep="_"),    
                          title2=myname,  xLab2="Genotype",  yLab2="Phenotype",   
                          height2=5,  width2=4.5,     Ymin2=min(DF_phe[i,]), Ymax2=max(DF_phe[i,]),    alpha2=1)

i=pOrder[14]
i
## DF_1[i,] 
myname = paste(DF_1[i,1], "and", DF_1[i,8], sep="  ")
My_Box_Violin_Scatte_Plot(vector2=as.vector(DF_phe[i,]),   sampleType2=as.vector(DF_gno[i,]),    
                          path2=AllResults_g,   fileName2=paste( "Top-14", i, sep="_"),    
                          title2=myname,  xLab2="Genotype",  yLab2="Phenotype",   
                          height2=5,  width2=4.5,     Ymin2=min(DF_phe[i,]), Ymax2=max(DF_phe[i,]),    alpha2=1)

i=pOrder[15]
i
## DF_1[i,] 
myname = paste(DF_1[i,1], "and", DF_1[i,8], sep="  ")
My_Box_Violin_Scatte_Plot(vector2=as.vector(DF_phe[i,]),   sampleType2=as.vector(DF_gno[i,]),    
                          path2=AllResults_g,   fileName2=paste( "Top-15", i, sep="_"),    
                          title2=myname,  xLab2="Genotype",  yLab2="Phenotype",   
                          height2=5,  width2=4.5,     Ymin2=min(DF_phe[i,]), Ymax2=max(DF_phe[i,]),    alpha2=1)

i=pOrder[16]
i
## DF_1[i,] 
myname = paste(DF_1[i,1], "and", DF_1[i,8], sep="  ")
My_Box_Violin_Scatte_Plot(vector2=as.vector(DF_phe[i,]),   sampleType2=as.vector(DF_gno[i,]),    
                          path2=AllResults_g,   fileName2=paste( "Top-16", i, sep="_"),  
                          title2=myname,  xLab2="Genotype",  yLab2="Phenotype",   
                          height2=5,  width2=4.5,     Ymin2=min(DF_phe[i,]), Ymax2=max(DF_phe[i,]),    alpha2=1)

i=pOrder[17]
i
## DF_1[i,] 
myname = paste(DF_1[i,1], "and", DF_1[i,8], sep="  ")
My_Box_Violin_Scatte_Plot(vector2=as.vector(DF_phe[i,]),   sampleType2=as.vector(DF_gno[i,]),    
                          path2=AllResults_g,   fileName2=paste( "Top-17", i, sep="_"),   
                          title2=myname,  xLab2="Genotype",  yLab2="Phenotype",   
                          height2=5,  width2=4.5,     Ymin2=min(DF_phe[i,]), Ymax2=max(DF_phe[i,]),    alpha2=1)

i=pOrder[18]
i
## DF_1[i,] 
myname = paste(DF_1[i,1], "and", DF_1[i,8], sep="  ")
My_Box_Violin_Scatte_Plot(vector2=as.vector(DF_phe[i,]),   sampleType2=as.vector(DF_gno[i,]),    
                          path2=AllResults_g,   fileName2=paste( "Top-18", i, sep="_"),  
                          title2=myname,  xLab2="Genotype",  yLab2="Phenotype",   
                          height2=5,  width2=4.5,     Ymin2=min(DF_phe[i,]), Ymax2=max(DF_phe[i,]),    alpha2=1)

i=pOrder[19]
i
## DF_1[i,] 
myname = paste(DF_1[i,1], "and", DF_1[i,8], sep="  ")
My_Box_Violin_Scatte_Plot(vector2=as.vector(DF_phe[i,]),   sampleType2=as.vector(DF_gno[i,]),    
                          path2=AllResults_g,   fileName2=paste( "Top-19", i, sep="_"),  
                          title2=myname,  xLab2="Genotype",  yLab2="Phenotype",   
                          height2=5,  width2=4.5,     Ymin2=min(DF_phe[i,]), Ymax2=max(DF_phe[i,]),     alpha2=1)

i=pOrder[20]
i
## DF_1[i,] 
myname = paste(DF_1[i,1], "and", DF_1[i,8], sep="  ")
My_Box_Violin_Scatte_Plot(vector2=as.vector(DF_phe[i,]),   sampleType2=as.vector(DF_gno[i,]),    
                          path2=AllResults_g,   fileName2=paste( "Top-20", i, sep="_"),   
                          title2=myname,  xLab2="Genotype",  yLab2="Phenotype",   
                          height2=5,  width2=4.5,     Ymin2=min(DF_phe[i,]), Ymax2=max(DF_phe[i,]),  alpha2=1)




 

###############################################################
random20 = sample.int(nrow(DF_1), 20, replace = FALSE)



i=random20[1]
## DF_1[i,] 
myname = paste(DF_1[i,1], "and", DF_1[i,8], sep="  ")
My_Box_Violin_Scatte_Plot(vector2=as.vector(DF_phe[i,]),   sampleType2=as.vector(DF_gno[i,]),    
                          path2=AllResults_g,   fileName2=paste( "random-1", i, sep="_"),    
                          title2=myname,  xLab2="Genotype",  yLab2="Phenotype",   
                          height2=5,  width2=4.5,   Ymin2=min(DF_phe[i,]), Ymax2=max(DF_phe[i,]),     alpha2=1)

i=random20[2]
## DF_1[i,] 
myname = paste(DF_1[i,1], "and", DF_1[i,8], sep="  ")
My_Box_Violin_Scatte_Plot(vector2=as.vector(DF_phe[i,]),   sampleType2=as.vector(DF_gno[i,]),    
                          path2=AllResults_g,   fileName2=paste( "random-2", i, sep="_"),     
                          title2=myname,  xLab2="Genotype",  yLab2="Phenotype",   
                          height2=5,  width2=4.5,   Ymin2=min(DF_phe[i,]), Ymax2=max(DF_phe[i,]),    alpha2=1)

i=random20[3]
## DF_1[i,] 
myname = paste(DF_1[i,1], "and", DF_1[i,8], sep="  ")
My_Box_Violin_Scatte_Plot(vector2=as.vector(DF_phe[i,]),   sampleType2=as.vector(DF_gno[i,]),    
                          path2=AllResults_g,   fileName2=paste( "random-3", i, sep="_"),     
                          title2=myname,  xLab2="Genotype",  yLab2="Phenotype",   
                          height2=5,  width2=4.5,     Ymin2=min(DF_phe[i,]), Ymax2=max(DF_phe[i,]),    alpha2=1)

i=random20[4]
i
## DF_1[i,] 
myname = paste(DF_1[i,1], "and", DF_1[i,8], sep="  ")
My_Box_Violin_Scatte_Plot(vector2=as.vector(DF_phe[i,]),   sampleType2=as.vector(DF_gno[i,]),    
                          path2=AllResults_g,   fileName2=paste( "random-4", i, sep="_"),     
                          title2=myname,  xLab2="Genotype",  yLab2="Phenotype",   
                          height2=5,  width2=4.5,     Ymin2=min(DF_phe[i,]), Ymax2=max(DF_phe[i,]),    alpha2=1)

i=random20[5]
i
## DF_1[i,] 
myname = paste(DF_1[i,1], "and", DF_1[i,8], sep="  ")
My_Box_Violin_Scatte_Plot(vector2=as.vector(DF_phe[i,]),   sampleType2=as.vector(DF_gno[i,]),    
                          path2=AllResults_g,   fileName2=paste( "random-5", i, sep="_"),    
                          title2=myname,  xLab2="Genotype",  yLab2="Phenotype",   
                          height2=5,  width2=4.5,     Ymin2=min(DF_phe[i,]), Ymax2=max(DF_phe[i,]),    alpha2=1)

i=random20[6]
i
## DF_1[i,] 
myname = paste(DF_1[i,1], "and", DF_1[i,8], sep="  ")
My_Box_Violin_Scatte_Plot(vector2=as.vector(DF_phe[i,]),   sampleType2=as.vector(DF_gno[i,]),    
                          path2=AllResults_g,   fileName2=paste( "random-6", i, sep="_"),   
                          title2=myname,  xLab2="Genotype",  yLab2="Phenotype",   
                          height2=5,  width2=4.5,     Ymin2=min(DF_phe[i,]), Ymax2=max(DF_phe[i,]),    alpha2=1)

i=random20[7]
i
## DF_1[i,] 
myname = paste(DF_1[i,1], "and", DF_1[i,8], sep="  ")
My_Box_Violin_Scatte_Plot(vector2=as.vector(DF_phe[i,]),   sampleType2=as.vector(DF_gno[i,]),    
                          path2=AllResults_g,   fileName2=paste( "random-7", i, sep="_"),      
                          title2=myname,  xLab2="Genotype",  yLab2="Phenotype",   
                          height2=5,  width2=4.5,     Ymin2=min(DF_phe[i,]), Ymax2=max(DF_phe[i,]),    alpha2=1)

i=random20[8]
i
## DF_1[i,] 
myname = paste(DF_1[i,1], "and", DF_1[i,8], sep="  ")
My_Box_Violin_Scatte_Plot(vector2=as.vector(DF_phe[i,]),   sampleType2=as.vector(DF_gno[i,]),    
                          path2=AllResults_g,   fileName2=paste( "random-8", i, sep="_"),  
                          title2=myname,  xLab2="Genotype",  yLab2="Phenotype",   
                          height2=5,  width2=4.5,     Ymin2=min(DF_phe[i,]), Ymax2=max(DF_phe[i,]),    alpha2=1)

i=random20[9]
i
## DF_1[i,] 
myname = paste(DF_1[i,1], "and", DF_1[i,8], sep="  ")
My_Box_Violin_Scatte_Plot(vector2=as.vector(DF_phe[i,]),   sampleType2=as.vector(DF_gno[i,]),    
                          path2=AllResults_g,   fileName2=paste( "random-9", i, sep="_"),  
                          title2=myname,  xLab2="Genotype",  yLab2="Phenotype",   
                          height2=5,  width2=4.5,     Ymin2=min(DF_phe[i,]), Ymax2=max(DF_phe[i,]),     alpha2=1)

i=random20[10]
i
## DF_1[i,] 
myname = paste(DF_1[i,1], "and", DF_1[i,8], sep="  ")
My_Box_Violin_Scatte_Plot(vector2=as.vector(DF_phe[i,]),   sampleType2=as.vector(DF_gno[i,]),    
                          path2=AllResults_g,   fileName2=paste( "random-10", i, sep="_"),   
                          title2=myname,  xLab2="Genotype",  yLab2="Phenotype",   
                          height2=5,  width2=4.5,      Ymin2=min(DF_phe[i,]), Ymax2=max(DF_phe[i,]),  alpha2=1)





i=random20[11]
## DF_1[i,] 
myname = paste(DF_1[i,1], "and", DF_1[i,8], sep="  ")
My_Box_Violin_Scatte_Plot(vector2=as.vector(DF_phe[i,]),   sampleType2=as.vector(DF_gno[i,]),    
                          path2=AllResults_g,  fileName2=paste( "random-11", i, sep="_"),    
                          title2=myname,  xLab2="Genotype",  yLab2="Phenotype",   
                          height2=5,  width2=4.5,   Ymin2=min(DF_phe[i,]), Ymax2=max(DF_phe[i,]),     alpha2=1)

i=random20[12]
## DF_1[i,] 
myname = paste(DF_1[i,1], "and", DF_1[i,8], sep="  ")
My_Box_Violin_Scatte_Plot(vector2=as.vector(DF_phe[i,]),   sampleType2=as.vector(DF_gno[i,]),    
                          path2=AllResults_g,   fileName2=paste( "random-12", i, sep="_"),   
                          title2=myname,  xLab2="Genotype",  yLab2="Phenotype",   
                          height2=5,  width2=4.5,   Ymin2=min(DF_phe[i,]), Ymax2=max(DF_phe[i,]),    alpha2=1)

i=random20[13]
## DF_1[i,] 
myname = paste(DF_1[i,1], "and", DF_1[i,8], sep="  ")
My_Box_Violin_Scatte_Plot(vector2=as.vector(DF_phe[i,]),   sampleType2=as.vector(DF_gno[i,]),    
                          path2=AllResults_g,   fileName2=paste( "random-13", i, sep="_"),    
                          title2=myname,  xLab2="Genotype",  yLab2="Phenotype",   
                          height2=5,  width2=4.5,     Ymin2=min(DF_phe[i,]), Ymax2=max(DF_phe[i,]),    alpha2=1)

i=random20[14]
i
## DF_1[i,] 
myname = paste(DF_1[i,1], "and", DF_1[i,8], sep="  ")
My_Box_Violin_Scatte_Plot(vector2=as.vector(DF_phe[i,]),   sampleType2=as.vector(DF_gno[i,]),    
                          path2=AllResults_g,   fileName2=paste( "random-14", i, sep="_"),    
                          title2=myname,  xLab2="Genotype",  yLab2="Phenotype",   
                          height2=5,  width2=4.5,     Ymin2=min(DF_phe[i,]), Ymax2=max(DF_phe[i,]),    alpha2=1)

i=random20[15]
i
## DF_1[i,] 
myname = paste(DF_1[i,1], "and", DF_1[i,8], sep="  ")
My_Box_Violin_Scatte_Plot(vector2=as.vector(DF_phe[i,]),   sampleType2=as.vector(DF_gno[i,]),    
                          path2=AllResults_g,   fileName2=paste( "random-15", i, sep="_"),    
                          title2=myname,  xLab2="Genotype",  yLab2="Phenotype",   
                          height2=5,  width2=4.5,     Ymin2=min(DF_phe[i,]), Ymax2=max(DF_phe[i,]),    alpha2=1)

i=random20[16]
i
## DF_1[i,] 
myname = paste(DF_1[i,1], "and", DF_1[i,8], sep="  ")
My_Box_Violin_Scatte_Plot(vector2=as.vector(DF_phe[i,]),   sampleType2=as.vector(DF_gno[i,]),    
                          path2=AllResults_g,   fileName2=paste( "random-16", i, sep="_"),  
                          title2=myname,  xLab2="Genotype",  yLab2="Phenotype",   
                          height2=5,  width2=4.5,     Ymin2=min(DF_phe[i,]), Ymax2=max(DF_phe[i,]),    alpha2=1)

i=random20[17]
i
## DF_1[i,] 
myname = paste(DF_1[i,1], "and", DF_1[i,8], sep="  ")
My_Box_Violin_Scatte_Plot(vector2=as.vector(DF_phe[i,]),   sampleType2=as.vector(DF_gno[i,]),    
                          path2=AllResults_g,   fileName2=paste( "random-17", i, sep="_"),   
                          title2=myname,  xLab2="Genotype",  yLab2="Phenotype",   
                          height2=5,  width2=4.5,     Ymin2=min(DF_phe[i,]), Ymax2=max(DF_phe[i,]),    alpha2=1)

i=random20[18]
i
## DF_1[i,] 
myname = paste(DF_1[i,1], "and", DF_1[i,8], sep="  ")
My_Box_Violin_Scatte_Plot(vector2=as.vector(DF_phe[i,]),   sampleType2=as.vector(DF_gno[i,]),    
                          path2=AllResults_g,   fileName2=paste( "random-18", i, sep="_"),  
                          title2=myname,  xLab2="Genotype",  yLab2="Phenotype",   
                          height2=5,  width2=4.5,     Ymin2=min(DF_phe[i,]), Ymax2=max(DF_phe[i,]),    alpha2=1)

i=random20[19]
i
## DF_1[i,] 
myname = paste(DF_1[i,1], "and", DF_1[i,8], sep="  ")
My_Box_Violin_Scatte_Plot(vector2=as.vector(DF_phe[i,]),   sampleType2=as.vector(DF_gno[i,]),    
                          path2=AllResults_g,   fileName2=paste( "random-19", i, sep="_"),  
                          title2=myname,  xLab2="Genotype",  yLab2="Phenotype",   
                          height2=5,  width2=4.5,     Ymin2=min(DF_phe[i,]), Ymax2=max(DF_phe[i,]),     alpha2=1)

i=random20[20]
i
## DF_1[i,] 
myname = paste(DF_1[i,1], "and", DF_1[i,8], sep="  ")
My_Box_Violin_Scatte_Plot(vector2=as.vector(DF_phe[i,]),   sampleType2=as.vector(DF_gno[i,]),    
                          path2=AllResults_g,   fileName2=paste( "random-20", i, sep="_"),   
                          title2=myname,  xLab2="Genotype",  yLab2="Phenotype",   
                          height2=5,  width2=4.5,   Ymin2=min(DF_phe[i,]), Ymax2=max(DF_phe[i,]),  alpha2=1)













DF_gno_times1 = DF_gno_times[myBool,]   
numMax = DF_gno_times1[,5] 
numMaxOrder = order(numMax)


#########################################

i=numMaxOrder[1]
## DF_1[i,] 
myname = paste(DF_1[i,1], "and", DF_1[i,8], sep="  ")
My_Box_Violin_Scatte_Plot(vector2=as.vector(DF_phe[i,]),   sampleType2=as.vector(DF_gno[i,]),    
                          path2=AllResults_g,   fileName2=paste( "numMax-1", i, sep="_"),    
                          title2=myname,  xLab2="Genotype",  yLab2="Phenotype",   
                          height2=5,  width2=4.5,   Ymin2=min(DF_phe[i,]), Ymax2=max(DF_phe[i,]),     alpha2=1)

i=numMaxOrder[2]
## DF_1[i,] 
myname = paste(DF_1[i,1], "and", DF_1[i,8], sep="  ")
My_Box_Violin_Scatte_Plot(vector2=as.vector(DF_phe[i,]),   sampleType2=as.vector(DF_gno[i,]),    
                          path2=AllResults_g,   fileName2=paste( "numMax-2", i, sep="_"),     
                          title2=myname,  xLab2="Genotype",  yLab2="Phenotype",   
                          height2=5,  width2=4.5,   Ymin2=min(DF_phe[i,]), Ymax2=max(DF_phe[i,]),    alpha2=1)

i=numMaxOrder[3]
## DF_1[i,] 
myname = paste(DF_1[i,1], "and", DF_1[i,8], sep="  ")
My_Box_Violin_Scatte_Plot(vector2=as.vector(DF_phe[i,]),   sampleType2=as.vector(DF_gno[i,]),    
                          path2=AllResults_g,   fileName2=paste( "numMax-3", i, sep="_"),     
                          title2=myname,  xLab2="Genotype",  yLab2="Phenotype",   
                          height2=5,  width2=4.5,     Ymin2=min(DF_phe[i,]), Ymax2=max(DF_phe[i,]),    alpha2=1)

i=numMaxOrder[4]
i
## DF_1[i,] 
myname = paste(DF_1[i,1], "and", DF_1[i,8], sep="  ")
My_Box_Violin_Scatte_Plot(vector2=as.vector(DF_phe[i,]),   sampleType2=as.vector(DF_gno[i,]),    
                          path2=AllResults_g,   fileName2=paste( "numMax-4", i, sep="_"),     
                          title2=myname,  xLab2="Genotype",  yLab2="Phenotype",   
                          height2=5,  width2=4.5,     Ymin2=min(DF_phe[i,]), Ymax2=max(DF_phe[i,]),    alpha2=1)

i=numMaxOrder[5]
i
## DF_1[i,] 
myname = paste(DF_1[i,1], "and", DF_1[i,8], sep="  ")
My_Box_Violin_Scatte_Plot(vector2=as.vector(DF_phe[i,]),   sampleType2=as.vector(DF_gno[i,]),    
                          path2=AllResults_g,   fileName2=paste( "numMax-5", i, sep="_"),    
                          title2=myname,  xLab2="Genotype",  yLab2="Phenotype",   
                          height2=5,  width2=4.5,     Ymin2=min(DF_phe[i,]), Ymax2=max(DF_phe[i,]),    alpha2=1)

i=numMaxOrder[6]
i
## DF_1[i,] 
myname = paste(DF_1[i,1], "and", DF_1[i,8], sep="  ")
My_Box_Violin_Scatte_Plot(vector2=as.vector(DF_phe[i,]),   sampleType2=as.vector(DF_gno[i,]),    
                          path2=AllResults_g,   fileName2=paste( "numMax-6", i, sep="_"),   
                          title2=myname,  xLab2="Genotype",  yLab2="Phenotype",   
                          height2=5,  width2=4.5,     Ymin2=min(DF_phe[i,]), Ymax2=max(DF_phe[i,]),    alpha2=1)

i=numMaxOrder[7]
i
## DF_1[i,] 
myname = paste(DF_1[i,1], "and", DF_1[i,8], sep="  ")
My_Box_Violin_Scatte_Plot(vector2=as.vector(DF_phe[i,]),   sampleType2=as.vector(DF_gno[i,]),    
                          path2=AllResults_g,   fileName2=paste( "numMax-7", i, sep="_"),      
                          title2=myname,  xLab2="Genotype",  yLab2="Phenotype",   
                          height2=5,  width2=4.5,     Ymin2=min(DF_phe[i,]), Ymax2=max(DF_phe[i,]),    alpha2=1)

i=numMaxOrder[8]
i
## DF_1[i,] 
myname = paste(DF_1[i,1], "and", DF_1[i,8], sep="  ")
My_Box_Violin_Scatte_Plot(vector2=as.vector(DF_phe[i,]),   sampleType2=as.vector(DF_gno[i,]),    
                          path2=AllResults_g,   fileName2=paste( "numMax-8", i, sep="_"),  
                          title2=myname,  xLab2="Genotype",  yLab2="Phenotype",   
                          height2=5,  width2=4.5,     Ymin2=min(DF_phe[i,]), Ymax2=max(DF_phe[i,]),    alpha2=1)

i=numMaxOrder[9]
i
## DF_1[i,] 
myname = paste(DF_1[i,1], "and", DF_1[i,8], sep="  ")
My_Box_Violin_Scatte_Plot(vector2=as.vector(DF_phe[i,]),   sampleType2=as.vector(DF_gno[i,]),    
                          path2=AllResults_g,   fileName2=paste( "numMax-9", i, sep="_"),  
                          title2=myname,  xLab2="Genotype",  yLab2="Phenotype",   
                          height2=5,  width2=4.5,     Ymin2=min(DF_phe[i,]), Ymax2=max(DF_phe[i,]),     alpha2=1)

i=numMaxOrder[10]
i
## DF_1[i,] 
myname = paste(DF_1[i,1], "and", DF_1[i,8], sep="  ")
My_Box_Violin_Scatte_Plot(vector2=as.vector(DF_phe[i,]),   sampleType2=as.vector(DF_gno[i,]),    
                          path2=AllResults_g,   fileName2=paste( "numMax-10", i, sep="_"),   
                          title2=myname,  xLab2="Genotype",  yLab2="Phenotype",   
                          height2=5,  width2=4.5,      Ymin2=min(DF_phe[i,]), Ymax2=max(DF_phe[i,]),  alpha2=1)





i=numMaxOrder[11]
## DF_1[i,] 
myname = paste(DF_1[i,1], "and", DF_1[i,8], sep="  ")
My_Box_Violin_Scatte_Plot(vector2=as.vector(DF_phe[i,]),   sampleType2=as.vector(DF_gno[i,]),    
                          path2=AllResults_g,  fileName2=paste( "numMax-11", i, sep="_"),    
                          title2=myname,  xLab2="Genotype",  yLab2="Phenotype",   
                          height2=5,  width2=4.5,   Ymin2=min(DF_phe[i,]), Ymax2=max(DF_phe[i,]),     alpha2=1)

i=numMaxOrder[12]
## DF_1[i,] 
myname = paste(DF_1[i,1], "and", DF_1[i,8], sep="  ")
My_Box_Violin_Scatte_Plot(vector2=as.vector(DF_phe[i,]),   sampleType2=as.vector(DF_gno[i,]),    
                          path2=AllResults_g,   fileName2=paste( "numMax-12", i, sep="_"),   
                          title2=myname,  xLab2="Genotype",  yLab2="Phenotype",   
                          height2=5,  width2=4.5,   Ymin2=min(DF_phe[i,]), Ymax2=max(DF_phe[i,]),    alpha2=1)

i=numMaxOrder[13]
## DF_1[i,] 
myname = paste(DF_1[i,1], "and", DF_1[i,8], sep="  ")
My_Box_Violin_Scatte_Plot(vector2=as.vector(DF_phe[i,]),   sampleType2=as.vector(DF_gno[i,]),    
                          path2=AllResults_g,   fileName2=paste( "numMax-13", i, sep="_"),    
                          title2=myname,  xLab2="Genotype",  yLab2="Phenotype",   
                          height2=5,  width2=4.5,     Ymin2=min(DF_phe[i,]), Ymax2=max(DF_phe[i,]),    alpha2=1)

i=numMaxOrder[14]
i
## DF_1[i,] 
myname = paste(DF_1[i,1], "and", DF_1[i,8], sep="  ")
My_Box_Violin_Scatte_Plot(vector2=as.vector(DF_phe[i,]),   sampleType2=as.vector(DF_gno[i,]),    
                          path2=AllResults_g,   fileName2=paste( "numMax-14", i, sep="_"),    
                          title2=myname,  xLab2="Genotype",  yLab2="Phenotype",   
                          height2=5,  width2=4.5,     Ymin2=min(DF_phe[i,]), Ymax2=max(DF_phe[i,]),    alpha2=1)

i=numMaxOrder[15]
i
## DF_1[i,] 
myname = paste(DF_1[i,1], "and", DF_1[i,8], sep="  ")
My_Box_Violin_Scatte_Plot(vector2=as.vector(DF_phe[i,]),   sampleType2=as.vector(DF_gno[i,]),    
                          path2=AllResults_g,   fileName2=paste( "numMax-15", i, sep="_"),    
                          title2=myname,  xLab2="Genotype",  yLab2="Phenotype",   
                          height2=5,  width2=4.5,     Ymin2=min(DF_phe[i,]), Ymax2=max(DF_phe[i,]),    alpha2=1)

i=numMaxOrder[16]
i
## DF_1[i,] 
myname = paste(DF_1[i,1], "and", DF_1[i,8], sep="  ")
My_Box_Violin_Scatte_Plot(vector2=as.vector(DF_phe[i,]),   sampleType2=as.vector(DF_gno[i,]),    
                          path2=AllResults_g,   fileName2=paste( "numMax-16", i, sep="_"),  
                          title2=myname,  xLab2="Genotype",  yLab2="Phenotype",   
                          height2=5,  width2=4.5,     Ymin2=min(DF_phe[i,]), Ymax2=max(DF_phe[i,]),    alpha2=1)

i=numMaxOrder[17]
i
## DF_1[i,] 
myname = paste(DF_1[i,1], "and", DF_1[i,8], sep="  ")
My_Box_Violin_Scatte_Plot(vector2=as.vector(DF_phe[i,]),   sampleType2=as.vector(DF_gno[i,]),    
                          path2=AllResults_g,   fileName2=paste( "numMax-17", i, sep="_"),   
                          title2=myname,  xLab2="Genotype",  yLab2="Phenotype",   
                          height2=5,  width2=4.5,     Ymin2=min(DF_phe[i,]), Ymax2=max(DF_phe[i,]),    alpha2=1)

i=numMaxOrder[18]
i
## DF_1[i,] 
myname = paste(DF_1[i,1], "and", DF_1[i,8], sep="  ")
My_Box_Violin_Scatte_Plot(vector2=as.vector(DF_phe[i,]),   sampleType2=as.vector(DF_gno[i,]),    
                          path2=AllResults_g,   fileName2=paste( "numMax-18", i, sep="_"),  
                          title2=myname,  xLab2="Genotype",  yLab2="Phenotype",   
                          height2=5,  width2=4.5,     Ymin2=min(DF_phe[i,]), Ymax2=max(DF_phe[i,]),    alpha2=1)

i=numMaxOrder[19]
i
## DF_1[i,] 
myname = paste(DF_1[i,1], "and", DF_1[i,8], sep="  ")
My_Box_Violin_Scatte_Plot(vector2=as.vector(DF_phe[i,]),   sampleType2=as.vector(DF_gno[i,]),    
                          path2=AllResults_g,   fileName2=paste( "numMax-19", i, sep="_"),  
                          title2=myname,  xLab2="Genotype",  yLab2="Phenotype",   
                          height2=5,  width2=4.5,     Ymin2=min(DF_phe[i,]), Ymax2=max(DF_phe[i,]),     alpha2=1)

i=numMaxOrder[20]
i
## DF_1[i,] 
myname = paste(DF_1[i,1], "and", DF_1[i,8], sep="  ")
My_Box_Violin_Scatte_Plot(vector2=as.vector(DF_phe[i,]),   sampleType2=as.vector(DF_gno[i,]),    
                          path2=AllResults_g,   fileName2=paste( "numMax-20", i, sep="_"),   
                          title2=myname,  xLab2="Genotype",  yLab2="Phenotype",   
                          height2=5,  width2=4.5,     Ymin2=min(DF_phe[i,]), Ymax2=max(DF_phe[i,]),  alpha2=1)











